Im working on the project 'moerder' since months. Unfortunally I cannot say how many hours on wich part I spent...
I started without any knowledge of Android - so it took a lot of time.

It is possible to start an QR scan out of the app. Actually its turned off, because for testing it is annoying.
All data is stored on Firebase DB, to sync game date between all player. Listeners are responsable for receiving the data.
The work with Firebase was the cause of most debugging time. I started with it without knowing about callback interfaces.

Actually game is completly running and playable. It can start with 1-8 players, just for testing reasons. There are a few bugs in suspection-funktions but even the app crashes, it catches all relevant data from db and is able to run again.

The structur of the app is really bad, actually. After debugging I will refactor that.

Most help and some small snippets are from "The Android Pro"-YouTube channel https://www.youtube.com/channel/UCUfd8ppTsczn8Wg-Ei1DW1g

The app is a result of a project from last semester on my german university in the modul "Human-Computer-Interaction". There we had the task to build an app prototype. It was build as html project, to show how we imagine our app when it would be builded.
I wanted to make this app real. Here it is.
