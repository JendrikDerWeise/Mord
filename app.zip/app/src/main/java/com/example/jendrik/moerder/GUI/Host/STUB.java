package com.example.jendrik.moerder.GUI.Host;

import android.app.Activity;
import android.os.Bundle;

import com.example.jendrik.moerder.R;


public class STUB extends Activity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stub_activity);


    }
}
