package com.example.jendrik.moerder.GUI.Join;


public interface GameStartedCallback {

    void startGameAfterReceivingInformation();
}
